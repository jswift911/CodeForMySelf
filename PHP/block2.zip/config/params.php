<?php

return [
    'admin_email' => 'jswift888@gmail.com',
    'shop_name' => 'Магазин ishop',
    'pagination' => 3,
    'smtp_host' => 'smtp.beget.com',
    'smtp_port' => '465',
    'smtp_protocol' => 'ssl',
    'smtp_login' => 'test@lee-web.online',
    'smtp_password' => 'Test123',
];