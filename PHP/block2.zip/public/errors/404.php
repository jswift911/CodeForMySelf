<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>404</title>
    <style>
        * {
            padding: 0;
            margin: 0 auto;
        }
    </style>
</head>
<body>

<img style="width: 100%; height: 100vh" src="/errors/404.jpg" alt="404">
</body>
</html>