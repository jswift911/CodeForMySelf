<?php


namespace app\controllers;
use ishop\base\Controller;

class PageController extends AppController
{

    public function indexAction() {

        debug($this->route);
        echo __METHOD__;

    }
}