<?php

return [
    'dsn' => 'mysql:host=localhost:3307;dbname=ishop;charset=utf8',
    'user' => 'root',
    'pass' => '',
];