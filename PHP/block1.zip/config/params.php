<?php

return [
    'admin_email' => 'admin@mail.ru',
    'shop_name' => 'Магазин ishop',
    'pagination' => 3,
    'smtp_login' => '',
    'smtp_password' => '',
];