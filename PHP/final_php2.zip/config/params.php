<?php

return [
    'admin_email' => 'jswift888@gmail.com',
    'shop_name' => 'Магазин ishop',
    'pagination' => 3,
    'smtp_host' => 'smtp.yandex.ru',
    'smtp_port' => '465',
    'smtp_protocol' => 'ssl',
    'smtp_login' => 'testdebuglee@yandex.ru',
    'smtp_password' => 'Debugtest3321',
    'img_width' => 125,
    'img_height' => 200,
    'gallery_width' => 700,
    'gallery_height' => 1000,
];